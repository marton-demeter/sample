'use strict';

class ArgParser {

  /**
   * Valid options:
   *     prog        (optional) - Program name
   *     usage       (optional) - Program usage
   *     description (optional) - Program description
   *     help        (optional) - Display help text if -h or --help arguments
   *                              are given
   */
  constructor(opts = {})
  {
    this.prog = opts.prog || process.argv.slice(1, 2).join();
    this.usage = opts.usage || 'No usage information provided';
    this.description = opts.description || 'No description provided';
    this.help = opts.help || true;
    this.argv = process.argv.slice(2);
    this.argc = process.argv.slice(2).length;
    this.args = {};

    if(this.help) {
      this.add_argument('--help', '-h', {
        help: 'Prints this message',
        action: 'this.print_help'
      });
    }
  }

  /**
   *  Valid options:
   *      flag     (required) - Flag (e.g. --flag)
   *      sflag    (optional) - Short flag (e.g. -f)
   *      action   (optional) - Function to execute when flag is encountered
   *      default  (optional) - Default value if not present in args (not implemented)
   *      required (optional) - Whether this argument is required (not implemented)
   *      help     (optional) - Description of argument
   *      nargs    (optional) - How many following args to consume
   */
  add_argument(flag = null, sflag = null, opts = {})
  {
    if(!flag) {
      console.error('Could not add new argument, flag not specified');
      return;
    }

    if(sflag instanceof Object) {
      opts = sflag;
      sflag = '';
    }

    let temp_obj = {};
    temp_obj.flag = flag;
    temp_obj.sflag = sflag || '';
    temp_obj.action = opts.action || (_ => _);
    temp_obj.default = opts.default || null;
    temp_obj.required = opts.required || false;
    temp_obj.help = opts.help || '';
    temp_obj.nargs = opts.nargs || 0;

    this.args[flag] = temp_obj;
  }

  parse_args(args = [])
  {
    if(!args.length) {
      args = this.argv;
    }

    for(;;) {
      if(!args.length) {
        break;
      }

      let a = args.slice(0, 1).join();
      args = args.slice(1);

      if(!Object.values(this.args).map(a => a.sflag).includes(a) &&
         !Object.values(this.args).map(a => a.flag).includes(a)) {
        continue;
      }

      if(this.args[a] != undefined) {
        a = this.args[a];
      } else {
        a = Object.values(this.args).filter(arg => arg.sflag == a)[0];
      }

      let nargs = [];
      if(a.nargs) {
        nargs = args.slice(0, a.nargs);
        args = args.slice(a.nargs);
      }

      if(a.action) {
        if(a.action === 'this.print_help') {
          this.print_help();
        } else {
          a.action(nargs);
        }
      }
    }
  }

  print_help()
  {
    if(!this.help) {
      return;
    }

    console.log('\n Help:\n');

    let pad = null;
    try {
      pad = require('@mdemeter/pad');
    } catch(err) {
      pad = require('./lib/pad/pad');
    }

    let multiline = null;
    try {
      multiline = require('@mdemeter/multiline').multiline;
    } catch(err) {
      multiline = require('./lib/multiline/multiline').multiline
    }

    console.log(`  ${pad.right('Program:', 13)}${this.prog}`);
    console.log(`  ${pad.right('Description:', 13)}${this.description}`);
    console.log(`  ${pad.right('Usage:', 13)}${this.usage}`);
    console.log();
    console.log(`  Flags:`);

    let max = 0;
    Object.values(this.args)
      .map(a => a.flag)
      .map(f => max = f.length > max ? f.length : max);

    const line_length = process.stdout.columns || 80;

    Object.keys(this.args).forEach(key => {
      let lines = [];
      let obj = this.args[key];

      let line = `   ${pad.right(obj.sflag, 4)}`;
      line += pad.right(obj.flag, max + 1);

      let taken_space = 7 + max + 1;
      let remaining_space = line_length - taken_space;
      if(obj.help) {
        let opts = { width: line_length, skip_first: true, pad_left: taken_space };
        line += multiline(obj.help, opts);
      }

      console.log(line);
    });
    console.log();

    if(this.suffix != null) {
      console.log(this.suffix);
    }
    process.exit(0);
  }

};

module.exports = { ArgParser }
